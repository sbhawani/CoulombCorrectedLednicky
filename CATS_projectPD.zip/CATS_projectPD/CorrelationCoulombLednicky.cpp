//#ifdef __CINT__
#include "TGraph.h"
#include "TGraph2D.h"
#include "TString.h"
#include "TLegend.h"
#include "TCanvas.h"
#include "TAxis.h"
#include "TFile.h"
//#endif
#include "CorrelationCoulombLednicky.h"

void Plot_Source_Pd(double rad) {
  printf("this is working!");
  const unsigned NumRadBins = 100;
  const double MinRad = 0;
  const double MaxRad = 10;

  TGraph *gSource = new TGraph();
  gSource->SetName("gSource");
  unsigned COUNTER = 0;
  for (double RAD = 0.1; RAD < MaxRad; RAD += 0.1) {
    gSource->SetPoint(COUNTER, RAD, SOURCE_4PI(RAD, rad));
    // printf("%f  %f", RAD, SOURCE_4PI(RAD, rad));
    COUNTER++;
  }
  TCanvas *Plot = new TCanvas("Plot", "Plot", 0, 0, 800, 600);
  TString pdfName =
      Form(
          "%sSourcePD.png",
          "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD");  //plots are output as .pdf If you prefer other formats simply change the ending
  printf("reached -2!");
  //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
  gSource->GetXaxis()->SetTitle("r (fm)");
  gSource->GetXaxis()->SetTitleSize(0.045);
  gSource->GetXaxis()->SetTitleOffset(0.75);
  gSource->GetYaxis()->SetTitleSize(0.045);
  gSource->GetYaxis()->SetTitleOffset(0.95);
  gSource->GetYaxis()->SetTitle("S_{4#pi}(r)(fm^{-1})");

  gSource->GetXaxis()->SetRangeUser(0, 10);
  gSource->GetYaxis()->SetRangeUser(0, 0.5);

  gSource->SetLineColor(kRed);
  gSource->SetLineWidth(2);
  //gSource->MarkerStyle(20);
  //gSource->MarkerSize(1.5);
  TLegend *leg1 = new TLegend(0.5, 0.5, 0.7, 0.65);
  leg1->SetFillStyle(0);
  leg1->SetTextSize(0.04);
  leg1->SetLineColor(0);
  leg1->SetNColumns(1);
  leg1->AddEntry(gSource, "  Gaussian Source");

  gSource->Draw("ACP");
  leg1->Draw("same");
  printf("reached -3!");
  Plot->Print(pdfName);
  delete Plot;
  delete gSource;
}

void CHECK_FOR_FUNCTIONS() {
  printf(
      "Plotting for Ac(), chi(), B(),P(),G() for pi pi tp check calculation is consistent!");
  const unsigned NumRadBins = 100;
  const double MinRad = 0;
  const double Maxk = 30;

  TGraph *gAc_repul = new TGraph();
  gAc_repul->SetName("gAc_repul");

  TGraph *gAc_att = new TGraph();
  gAc_att->SetName("gAc_att");

  TGraph *ReChi = new TGraph();
  ReChi->SetName("ReChi");

  TGraph *ImChi_repul = new TGraph();
  ImChi_repul->SetName("ImChi_repul");

  TGraph *ImChi_att = new TGraph();
  ImChi_att->SetName("ImChi");

  //TGraph *gB = new TGraph();
  // gB->SetName("gB");

  TGraph *gB1 = new TGraph();
  gB1->SetName("gB1");
  TGraph *gB2 = new TGraph();
  gB2->SetName("gB2");
  TGraph *gB3 = new TGraph();
  gB3->SetName("gB3");

  TGraph *gB12 = new TGraph();
  gB12->SetName("gB12");
  TGraph *gB22 = new TGraph();
  gB22->SetName("gB22");
  TGraph *gB32 = new TGraph();
  gB32->SetName("gB32");

  TGraph *gP1 = new TGraph();
  gP1->SetName("gP1");
  TGraph *gP2 = new TGraph();
  gP2->SetName("gP2");
  TGraph *gP3 = new TGraph();
  gP3->SetName("gP3");

  TGraph *gP12 = new TGraph();
  gP12->SetName("gP12");
  TGraph *gP22 = new TGraph();
  gP22->SetName("gP22");
  TGraph *gP32 = new TGraph();
  gP32->SetName("gP32");

  TGraph *gReG1 = new TGraph();
  gReG1->SetName("gReG1");
  TGraph *gReG2 = new TGraph();
  gReG2->SetName("gReG2");
  TGraph *gReG3 = new TGraph();
  gReG3->SetName("gReG3");

  TGraph *gImG1 = new TGraph();
  gImG1->SetName("gImG1");
  TGraph *gImG2 = new TGraph();
  gImG2->SetName("gImG2");
  TGraph *gImG3 = new TGraph();
  gImG3->SetName("gImG3");

  unsigned COUNTER = 0;
  for (double Inveta = 2; Inveta < Maxk; Inveta += 1) {
    gAc_repul->SetPoint(COUNTER, Inveta, Ac(1 / Inveta));
    gAc_att->SetPoint(COUNTER, Inveta, Ac(-1 / Inveta));
    ReChi->SetPoint(COUNTER, Inveta, h(1 / Inveta));
    ImChi_repul->SetPoint(COUNTER, Inveta, Ac(1 / Inveta) / 2 * Inveta);
    ImChi_att->SetPoint(COUNTER, Inveta, -Ac(-1 / Inveta) / 2 * Inveta);
    //printf("%f  %f\n", k, GET_CORRELATION(k, ScatLend, EffecRange, ChargeRad, SourceRad));
    COUNTER++;
  }

  unsigned counter = 0;
  for (double Inveta = 0.001; Inveta < Maxk; Inveta += 1) {
    ReChi->SetPoint(counter, Inveta, h(1 / Inveta));
    ImChi_repul->SetPoint(counter, Inveta, Ac(1 / Inveta) / 2 * Inveta);
    ImChi_att->SetPoint(counter, Inveta, -Ac(-1 / Inveta) / 2 * Inveta);
    //printf("%f  %f\n", k, GET_CORRELATION(k, ScatLend, EffecRange, ChargeRad, SourceRad));
    counter++;
  }

  unsigned counter2 = 0;
  const double rval1 = 5 * FmToNu;  // fm to nu
  const double rval2 = 15 * FmToNu;  // fm to nu
  const double rval3 = 50 * FmToNu;  // fm to nu
  const double ac = -387.5 * FmToNu;  // fm to nu charged radius

  //double B(double rho, double eta);  //recursive sum on bn
  // double P(double rho, double eta);//recursive sum on pn
  //TILDE_G(double rho, double eta);//

  for (double Q = 0.01; Q < 50; Q += 1) {
    gB1->SetPoint(counter2, Q, B(Q / 2 * rval1, 2 / Q / ac));
    gB2->SetPoint(counter2, Q, B(Q / 2 * rval2, 2 / Q / ac));
    gB3->SetPoint(counter2, Q, B(Q / 2 * rval3, 2 / Q / ac));

    gB12->SetPoint(counter2, Q, sin(Q / 2 * rval1) / (Q / 2 * rval1));
    gB22->SetPoint(counter2, Q, sin(Q / 2 * rval2) / (Q / 2 * rval2));
    gB32->SetPoint(counter2, Q, sin(Q / 2 * rval3) / (Q / 2 * rval3));

    gP1->SetPoint(counter2, Q, P(Q / 2 * rval1, 2 / Q / ac));
    gP2->SetPoint(counter2, Q, P(Q / 2 * rval2, 2 / Q / ac));
    gP3->SetPoint(counter2, Q, P(Q / 2 * rval3, 2 / Q / ac));

    gP12->SetPoint(counter2, Q, cos(Q / 2 * rval1));
    gP22->SetPoint(counter2, Q, cos(Q / 2 * rval2));
    gP32->SetPoint(counter2, Q, cos(Q / 2 * rval3));

    gReG1->SetPoint(counter2, Q, real(TILDE_G(Q / 2 * rval1, 2 / Q / ac)));
    gReG2->SetPoint(counter2, Q, real(TILDE_G(Q / 2 * rval2, 2 / Q / ac)));
    gReG3->SetPoint(counter2, Q, real(TILDE_G(Q / 2 * rval3, 2 / Q / ac)));

    gImG1->SetPoint(counter2, Q, imag(TILDE_G(Q / 2 * rval1, 2 / Q / ac)));
    gImG2->SetPoint(counter2, Q, imag(TILDE_G(Q / 2 * rval2, 2 / Q / ac)));
    gImG3->SetPoint(counter2, Q, imag(TILDE_G(Q / 2 * rval3, 2 / Q / ac)));

    counter2++;
  }

  TFile *OutputFile =
      new TFile(
          TString::Format(
              "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/CHECK_FOR_FUNCTION_2Approx.root"),
          "recreate");
  printf("File Created\n");
  TCanvas *Plot = new TCanvas("Plot", "Plot", 0, 0, 800, 600);
  TString pdfName =
      Form(
          "%sCkPD.png",
          "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD");  //plots are output as .pdf If you prefer other formats simply change the ending
  printf("reached -2!");
  //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
  /*gCk->GetXaxis()->SetTitle("k (MeV/c)");
   gCk->GetXaxis()->SetTitleSize(0.045);
   gCk->GetXaxis()->SetTitleOffset(0.75);
   gCk->GetYaxis()->SetTitleSize(0.045);
   gCk->GetYaxis()->SetTitleOffset(0.95);
   gCk->GetYaxis()->SetTitle("#it{C}(k)");

   gCk->GetXaxis()->SetRangeUser(0, 200);
   gCk->GetYaxis()->SetRangeUser(0, 10);

   gCk->SetLineColor(kRed);
   gCk->SetLineWidth(2);
   //gSource->MarkerStyle(20);
   //gSource->MarkerSize(1.5);
   TLegend *leg1 = new TLegend(0.5, 0.5, 0.7, 0.65);
   leg1->SetFillStyle(0);
   leg1->SetTextSize(0.04);
   leg1->SetLineColor(0);
   leg1->SetNColumns(1);
   leg1->AddEntry(gCk, " Ck pd Lednicky Coulomb");

   gCk->Draw("ACP");
   leg1->Draw("same");
   printf("reached -3!");*/
  gAc_repul->Write();
  gAc_att->Write();
  ReChi->Write();
  ImChi_repul->Write();
  ImChi_att->Write();

  //gB->Write();
  gB1->Write();
  gB2->Write();
  gB3->Write();
  gB12->Write();
  gB22->Write();
  gB32->Write();

  //gP->Write();

  gP1->Write();
  gP2->Write();
  gP3->Write();
  gP12->Write();
  gP22->Write();
  gP32->Write();

  gReG1->Write();
  gReG2->Write();
  gReG3->Write();
  gImG1->Write();
  gImG2->Write();
  gImG3->Write();

  Plot->Print(pdfName);
  delete Plot;
  delete gAc_repul;
  delete gAc_att;
  delete ReChi;
  delete ImChi_repul;
  delete ImChi_att;

  delete gB1;
  delete gB2;
  delete gB3;
  delete gB12;
  delete gB22;
  delete gB32;

  delete gP1;
  delete gP2;
  delete gP3;
  delete gP12;
  delete gP22;
  delete gP32;

  delete gReG1;
  delete gReG2;
  delete gReG3;
  delete gImG1;
  delete gImG2;
  delete gImG3;

  delete OutputFile;
}

void Plot_CoulombLed_WF_ForPd(double k, double t, double ScatLend,
                              double EffecRange, double ChargeRad) {

  printf("Plotting WF from Coulomb Lednicky!");
  const double MaxRad = 100;

  TGraph *gReWF = new TGraph();
  TGraph *gImWF = new TGraph();
  gReWF->SetName("gReWF");
  gImWF->SetName("gImWF");
  unsigned COUNTER = 0;
  for (double RAD = 0.001; RAD < MaxRad; RAD += 1) {
    gReWF->SetPoint(
        COUNTER, RAD,
        real(LEDNICKY_COULOMB_WF(k, RAD, t, ScatLend, EffecRange, ChargeRad)));
    gImWF->SetPoint(
        COUNTER, RAD,
        imag(LEDNICKY_COULOMB_WF(k, RAD, t, ScatLend, EffecRange, ChargeRad)));
    printf(
        "%f  %f  %f\n", RAD,
        real(LEDNICKY_COULOMB_WF(k, RAD, t, ScatLend, EffecRange, ChargeRad)),
        imag(LEDNICKY_COULOMB_WF(k, RAD, t, ScatLend, EffecRange, ChargeRad)));
    COUNTER++;
  }
  TCanvas *Plot = new TCanvas("Plot", "Plot", 0, 0, 800, 600);
  TString pdfName =
      Form(
          "%sWF_k=.png",
          "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD");  //plots are output as .pdf If you prefer other formats simply change the ending
  printf("reached -2!");
  //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
  gReWF->GetXaxis()->SetTitle("r (fm)");
  gReWF->GetXaxis()->SetTitleSize(0.045);
  gReWF->GetXaxis()->SetTitleOffset(0.75);
  gReWF->GetYaxis()->SetTitleSize(0.045);
  gReWF->GetYaxis()->SetTitleOffset(0.95);
  gReWF->GetYaxis()->SetTitle("#psi(r)");

  gReWF->GetXaxis()->SetRangeUser(0, 100);
  gReWF->GetYaxis()->SetRangeUser(-10, 10);

  gImWF->SetLineColor(kBlue);
  gImWF->SetLineWidth(2);

  gReWF->SetLineColor(kRed);
  gReWF->SetLineWidth(2);
  //gSource->MarkerStyle(20);
  //gSource->MarkerSize(1.5);
  TLegend *leg1 = new TLegend(0.65, 0.6, 0.75, 0.75);
  leg1->SetFillStyle(0);
  leg1->SetTextSize(0.06);
  leg1->SetLineColor(0);
  leg1->SetNColumns(1);

  leg1->AddEntry(gReWF, "#Rgothic [#psi]", "pef");
  leg1->AddEntry(gImWF, "#Jgothic [#psi]", "pef");

  gReWF->Draw("ACP");
  gImWF->Draw("ACPsame");
  leg1->Draw("same");
  printf("reached -2!");
  Plot->Print(pdfName);
  delete Plot;
  delete gReWF;
  delete gImWF;
}

void Plot_CoulombLed_Density_ForPd(double k, double t, double ScatLend,
                                   double EffecRange, double ChargeRad,
                                   bool draw2D) {

  printf("Plotting WF from Coulomb Lednicky!");
  const double MaxRad = 30;
  const double kMax = 300;
  TCanvas *Plot = new TCanvas("Plot", "Plot", 0, 0, 800, 600);
  TString pdfName =
      Form(
          "%sDensityWF_k=.png",
          "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD");  //plots are output as .pdf If you prefer other formats simply change the ending
  printf("reached -2!");

  if (draw2D) {

    TGraph2D *g2DDensity = new TGraph2D();
    g2DDensity->SetName("gDensity");
    unsigned COUNTER = 0;
    for (double kval = 0.0001; kval < kMax; kval += 2) {
      for (double RAD = 0.0001; RAD < MaxRad; RAD += 2) {
        g2DDensity->SetPoint(
            COUNTER,
            RAD,
            kval,
            PROB_LEDNICKY_COULOMB_WF(kval, RAD, t, ScatLend, EffecRange,
                                     ChargeRad));
        printf(
            "%f  %f\n",
            RAD,
            PROB_LEDNICKY_COULOMB_WF(kval, RAD, t, ScatLend, EffecRange,
                                     ChargeRad));
        COUNTER++;
      }
    }

    //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
    g2DDensity->GetXaxis()->SetTitle("r(fm)");
    g2DDensity->GetXaxis()->SetTitleSize(0.045);
    g2DDensity->GetXaxis()->SetTitleOffset(1.0);
    g2DDensity->GetYaxis()->SetTitleSize(0.045);
    g2DDensity->GetYaxis()->SetTitleOffset(1.2);
    //g2DDensity->GetYaxis()->SetTitle("k*(MeV/c)");
    g2DDensity->GetZaxis()->SetTitle("|#psi_{k}^{2}(k)|)");
    g2DDensity->SetTitle("|#psi_{k}^{2}(k)|); r(fm); k*(MeV/c)");
    g2DDensity->GetXaxis()->SetRangeUser(0, 80);
    g2DDensity->GetYaxis()->SetRangeUser(0, 200);
    //g2DDensity->SetLineColor(kRed);
    g2DDensity->SetLineWidth(1);
    //g2DDensity->MarkerStyle(20);
    //gSource->MarkerSize(1.5);
    TLegend *leg1 = new TLegend(0.65, 0.6, 0.75, 0.75);
    leg1->SetFillStyle(0);
    leg1->SetTextSize(0.06);
    leg1->SetLineColor(0);
    leg1->SetNColumns(1);

    leg1->AddEntry(g2DDensity, "|#psi_{k}^{2}(r)|", "pef");

    g2DDensity->Draw("surf1");
    //leg1->Draw("same");
    printf("reached -2!");
    Plot->Print(pdfName);
    delete Plot;
    delete g2DDensity;

  } else {

    TGraph *gDensity = new TGraph();
    gDensity->SetName("gDensity");
    unsigned COUNTER = 0;
    for (double RAD = 0.001; RAD < MaxRad; RAD += 1) {
      gDensity->SetPoint(
          COUNTER, RAD,
          PROB_LEDNICKY_COULOMB_WF(k, RAD, t, ScatLend, EffecRange, ChargeRad));
      // printf(
      //    "%f  %f\n", RAD,
      //    PROB_LEDNICKY_COULOMB_WF(k, RAD, t, ScatLend, EffecRange, ChargeRad));
      COUNTER++;
    }

    //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
    gDensity->GetXaxis()->SetTitle("r(fm)");
    gDensity->GetXaxis()->SetTitleSize(0.045);
    gDensity->GetXaxis()->SetTitleOffset(0.75);
    gDensity->GetYaxis()->SetTitleSize(0.045);
    gDensity->GetYaxis()->SetTitleOffset(0.95);
    gDensity->GetYaxis()->SetTitle("|#psi_{k}^{2}(k)|)");

    gDensity->GetXaxis()->SetRangeUser(0, 100);
    gDensity->GetYaxis()->SetRangeUser(-10, 10);
    gDensity->SetLineColor(kRed);
    gDensity->SetLineWidth(2);
    //gSource->MarkerStyle(20);
    //gSource->MarkerSize(1.5);
    TLegend *leg1 = new TLegend(0.65, 0.6, 0.75, 0.75);
    leg1->SetFillStyle(0);
    leg1->SetTextSize(0.06);
    leg1->SetLineColor(0);
    leg1->SetNColumns(1);

    leg1->AddEntry(gDensity, "|#psi_{k}^{2}(r)|", "pef");

    gDensity->Draw("ACP");
    leg1->Draw("same");
    printf("reached -2!");
    Plot->Print(pdfName);
    delete Plot;
    delete gDensity;
  }
}

void Plot_CoulombLed_Correlation_ForPd(double ScatLend1, double EffecRange1,
                                       double ScatLend2, double EffecRange2,
                                       double ChargeRad, bool SourceRad) {
  printf("this is working!");
  const unsigned NumRadBins = 100;
  const double MinRad = 0;
  const double Maxk = 140;

  TGraph *gCk = new TGraph();
  gCk->SetName("gCk");
  unsigned COUNTER = 0;
  for (double k = 0.1; k < Maxk; k += 10) {
    gCk->SetPoint(
        COUNTER,
        k,
        0.666 * GET_CORRELATION(k, ScatLend1, EffecRange1, ChargeRad, SourceRad)
            + 0.333
                * GET_CORRELATION(k, ScatLend2, EffecRange2, ChargeRad,
                                  SourceRad));
    /* printf(
     "%f  %f\n",
     k,
     2 / 3 * GET_CORRELATION(k, ScatLend1, EffecRange1, ChargeRad, SourceRad)
     + 1 / 3
     * GET_CORRELATION(k, ScatLend2, EffecRange2, ChargeRad,
     SourceRad));*/
    COUNTER++;
  }

  TFile *OutputFile =
      new TFile(
          TString::Format(
              "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/ProtonDeuteronCkLedCoulombUpdatedScatterParAprrox.root"),
          "recreate");
  printf("File Created\n");
  TCanvas *Plot = new TCanvas("Plot", "Plot", 0, 0, 800, 600);
  TString pdfName =
      Form(
          "%sCkPD.png",
          "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD");  //plots are output as .pdf If you prefer other formats simply change the ending
  printf("reached -2!");
  //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
  gCk->GetXaxis()->SetTitle("k (MeV/c)");
  gCk->GetXaxis()->SetTitleSize(0.045);
  gCk->GetXaxis()->SetTitleOffset(0.75);
  gCk->GetYaxis()->SetTitleSize(0.045);
  gCk->GetYaxis()->SetTitleOffset(0.95);
  gCk->GetYaxis()->SetTitle("#it{C}(k)");

  gCk->GetXaxis()->SetRangeUser(0, 200);
  gCk->GetYaxis()->SetRangeUser(0, 10);

  gCk->SetLineColor(kRed);
  gCk->SetLineWidth(2);
  //gSource->MarkerStyle(20);
  //gSource->MarkerSize(1.5);
  TLegend *leg1 = new TLegend(0.5, 0.5, 0.7, 0.65);
  leg1->SetFillStyle(0);
  leg1->SetTextSize(0.04);
  leg1->SetLineColor(0);
  leg1->SetNColumns(1);
  leg1->AddEntry(gCk, " Ck pd Lednicky Coulomb");

  gCk->Draw("ACP");
  leg1->Draw("same");
  printf("reached -3!");
  gCk->Write();
  Plot->Print(pdfName);
  delete Plot;
  delete gCk;
  delete OutputFile;
}
void PLOT_CORRELATION_SIMPSON_METHOD(double ScatLend1, double EffecRange1,
                                     double ScatLend2, double EffecRange2,
                                     double ChargeRad, double SourceRad,bool plotall,bool QS) {
  printf("this is working!");
  const unsigned NumRadBins = 40;
  const double MinRad = 0;
  const double Maxk = 200;

  const double Scat1_Brokman = 11.4;  //quartet
  const double EffRange1_Brokman = 4.0;
  const double Scat2_Brokman = 1.2;  //doublet
  const double EffRange2_Brokman = 4.0;

  const double Scat1_Arvieux = 11.88;  //quartet
  const double EffRange1_Arvieux = 4.0;
  const double Scat2_Arvieux = 2.73;  //doublet
  const double EffRange2_Arvieux = 4.0;

  const double Scat1_Huttel = 11.1;  //quartet
  const double EffRange1_Huttel = 4.0;
  const double Scat2_Huttel = 4.0;  //doublet
  const double EffRange2_Huttel = 4.0;

  const double Scat1_Keivsky = 13.1;  //quartet
  const double EffRange1_Keivsky = 4.0;
  const double Scat2_Keivsky = 0.024;  //doublet
  const double EffRange2_Keivsky = 4.0;

  const double Scat1_Black = 14.7;  //quartet
  const double EffRange1_Black = 4.0;
  const double Scat2_Black = 0.024;   //doublet
  const double EffRange2_Black = 4.0;

  TGraph *gCk = new TGraph();
  TGraph *gCk_Brockman = new TGraph();
  TGraph *gCk_Arveux = new TGraph();
  TGraph *gCk_Huttel = new TGraph();
  TGraph *gCk_Keivsky = new TGraph();
  TGraph *gCk_Black = new TGraph();

  gCk->SetName("TestBlack ");
  gCk_Brockman->SetName("gCk_Brockman");
  gCk_Arveux->SetName("gCk_Arveux");
  gCk_Huttel->SetName("gCk_Huttel");
  gCk_Keivsky->SetName("gCk_Keivsky");
  gCk_Black->SetName("gCk_Black");

  unsigned COUNTER = 0;
  for (double k = 5; k < Maxk; k += 5) {
    if (plotall) {
      gCk_Brockman->SetPoint(
          COUNTER,
          k,0.666* GET_CORRELATION_SIMPSON2D(k, Scat1_Brokman, EffRange1_Brokman,
                                          ChargeRad, SourceRad)
              + 0.333
                  * GET_CORRELATION_SIMPSON2D(k, Scat2_Brokman,
                                              EffRange2_Brokman, ChargeRad,
                                              SourceRad));
      gCk_Arveux->SetPoint(
          COUNTER,
          k,0.666* GET_CORRELATION_SIMPSON2D(k, Scat1_Arvieux, EffRange1_Arvieux,
                                          ChargeRad, SourceRad)
              + 0.333
                  * GET_CORRELATION_SIMPSON2D(k, Scat2_Arvieux,
                                              EffRange2_Arvieux, ChargeRad,
                                              SourceRad));
      gCk_Huttel->SetPoint(
          COUNTER,
          k,
          0.666
              * GET_CORRELATION_SIMPSON2D(k, Scat1_Huttel, EffRange1_Huttel,
                                          ChargeRad, SourceRad)
              + 0.333
                  * GET_CORRELATION_SIMPSON2D(k, Scat2_Huttel, EffRange2_Huttel,
                                              ChargeRad, SourceRad));

      gCk_Keivsky->SetPoint(
          COUNTER,
          k,0.666* GET_CORRELATION_SIMPSON2D(k, Scat1_Keivsky, EffRange1_Keivsky,
                                          ChargeRad, SourceRad)
              + 0.333
                  * GET_CORRELATION_SIMPSON2D(k, Scat2_Keivsky,
                                              EffRange2_Keivsky, ChargeRad,
                                              SourceRad));
      gCk_Black->SetPoint(
          COUNTER,
          k,0.666* GET_CORRELATION_SIMPSON2D(k, Scat1_Black, EffRange1_Black,
                                          ChargeRad, SourceRad)
              + 0.333
                  * GET_CORRELATION_SIMPSON2D(k, Scat2_Black, EffRange2_Black,
                                              ChargeRad, SourceRad));
    } else {
      if(QS){
      gCk->SetPoint(
          COUNTER,k, (1.0/4.0 * GET_CORRELATION_SIMPSON2D(k, ScatLend1, EffecRange1,ChargeRad,SourceRad) + 3.0/4.0*GET_CORRELATION_SIMPSON2D(k , ScatLend2, EffecRange2,ChargeRad,SourceRad))-0.5*exp(-SourceRad*SourceRad*4.*k*k));
    }else{
      gCk->SetPoint(
                COUNTER,k, (1.0/2.0 * GET_CORRELATION_SIMPSON2D(k, ScatLend1, EffecRange1,ChargeRad,SourceRad) + 1.0/2.0*GET_CORRELATION_SIMPSON2D(k , ScatLend2, EffecRange2,ChargeRad,SourceRad)));

      }
    }
    COUNTER++;
  }
  TString OutputFileName = "";
  if (plotall) {
    OutputFileName =
        OutputFileName
            + "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/Protondeuteron_All_ScatteringRad0p994EffRange4p0.root";
  } else {
    OutputFileName =
        OutputFileName
            + "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/ProtonDMesonMinusFull.root";
  }
  TFile *OutputFile = new TFile(OutputFileName, "recreate");
  printf("File Created\n");
  TCanvas *Plot = new TCanvas("Plot", "Plot", 0, 0, 800, 600);
  TString pdfName = "";
  if (plotall) {
    pdfName =
        pdfName
            + Form(
                "%sCkPD_allRad0p994.pdf",
                "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/");
  } else {
    pdfName =
        pdfName
            + Form(
                "%sCkPDMesonMinunFull.pdf",
                "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/");
  }  //plots are output as .pdf If you prefer other formats simply change the ending
  printf("reached -2!");
  //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
  if (plotall) {
    gCk_Brockman->GetXaxis()->SetTitle("k (MeV/c)");
    gCk_Brockman->GetXaxis()->SetTitleSize(0.045);
    gCk_Brockman->GetXaxis()->SetTitleOffset(0.5);
    gCk_Brockman->GetYaxis()->SetTitleSize(0.045);
    gCk_Brockman->GetYaxis()->SetTitleOffset(0.65);
    gCk_Brockman->GetYaxis()->SetTitle("#it{C}(k)");

    gCk_Brockman->GetXaxis()->SetRangeUser(0, 200);
    gCk_Brockman->GetYaxis()->SetRangeUser(0, 10);

    gCk_Arveux->SetLineColor(kRed);
    gCk_Arveux->SetLineWidth(1.5);

    gCk_Huttel->SetLineColor(kBlack);
    gCk_Huttel->SetLineWidth(1.5);

    gCk_Keivsky->SetLineColor(kGreen);
    gCk_Keivsky->SetLineWidth(1.5);

    gCk_Black->SetLineColor(kBlue);
    gCk_Black->SetLineWidth(1.5);

    gCk_Arveux->SetLineStyle(10);
    gCk_Keivsky->SetLineStyle(8);
    gCk_Black->SetLineStyle(5);
    gCk_Huttel->SetLineStyle(4);
    gCk_Brockman->SetLineStyle(3);
    gCk_Arveux->SetMarkerStyle(25);
    gCk_Keivsky->SetMarkerStyle(26);
    gCk_Black->SetMarkerStyle(27);
    gCk_Huttel->SetMarkerStyle(28);
    gCk_Brockman->SetMarkerStyle(29);

    //gSource->MarkerStyle(20);
    //gSource->MarkerSize(1.5);
    TLegend
    *leg1 = new TLegend(0.5, 0.5, 0.7, 0.65);
    leg1->SetFillStyle(0);
    leg1->SetTextSize(0.04);
    leg1->SetLineColor(0);
    leg1->SetNColumns(1);
    leg1->AddEntry(gCk_Brockman, "Ck van Oers,Brockman (1967)");
    leg1->AddEntry(gCk_Arveux, "Ck Arvieux (1973)");
    leg1->AddEntry(gCk_Huttel, "Ck Huttel et al.(1983)");
    leg1->AddEntry(gCk_Keivsky, "Ck Kievsky et al.(1997)");
    leg1->AddEntry(gCk_Black, " Ck Black et al.(1999)");
    gCk_Brockman->Draw("ACP");
    gCk_Arveux->Draw("same");
    gCk_Huttel->Draw("same ");
    gCk_Keivsky->Draw("same");
    gCk_Black->Draw("same");
    leg1->Draw("same");
    printf("reached -3!");
    gCk_Brockman->Write();
    gCk_Arveux->Write();
    gCk_Huttel->Write();
    gCk_Keivsky->Write();
    gCk_Black->Write();
    Plot->Print(pdfName);
  } else {
    gCk->GetXaxis()->SetTitle("k (MeV/c)");
    gCk->GetXaxis()->SetTitleSize(0.045);
    gCk->GetXaxis()->SetTitleOffset(0.75);
    gCk->GetYaxis()->SetTitleSize(0.045);
    gCk->GetYaxis()->SetTitleOffset(0.95);
    gCk->GetYaxis()->SetTitle("#it{C}(k)");

    gCk->GetXaxis()->SetRangeUser(0, 200);
    gCk->GetYaxis()->SetRangeUser(0, 10);

    gCk->SetLineColor(kRed);
    gCk->SetLineWidth(2);
    //gSource->MarkerStyle(20);
    //gSource->MarkerSize(1.5);
    TLegend *leg1 = new TLegend(0.2, 0.5, 0.7, 0.65);
    leg1->SetFillStyle(0);
    leg1->SetTextSize(0.04);
    leg1->SetLineColor(0);
    leg1->SetNColumns(1);
    leg1->AddEntry(gCk, " Ck D^{-}-p [a_{0}= 0.07, a_{1} = -0.45]");

    gCk->Draw("ACP");
    leg1->Draw("same");
    printf("reached -3!");
    gCk->Write();
    Plot->Print(pdfName);
  }
  delete Plot;
  delete gCk;
  delete gCk_Brockman;
  delete gCk_Arveux;
  delete gCk_Huttel;
  delete gCk_Keivsky;
  delete gCk_Black;
  delete OutputFile;
}

void PLOT_CORRELATION_PROTON_DMESON(double ChargeRad, double SourceRad,bool plotall) {
  printf("this is working!");
  const unsigned NumRadBins = 80;
  const double MinRad = 0;
  const double Maxk = 400;

  //quark gluon exchange Model
  const double aI0 = -0.13;  //ISOSpin 0
  const double rI0 = 0.0;
  const double aI1 = -0.29;  //ISOSpin 1
  const double rI1 = 0.0;
  //Full Model
  const double aI0full = 0.07;  //ISOSpin 0
  const double rI0full = 0.0;
  const double aI1full = -0.45;  //ISOSpin 1
  const double rI1full = 0.0;

  const double wChannel1 = 0.5; // ISO Spin 0
  const double wChannel2 = 0.5; // ISO Spin 1


  TGraph *gCk = new TGraph();
  TGraph *gCk_PDqgModel = new TGraph();
  TGraph *gCk_FullModel = new TGraph();

  gCk->SetName("TestBlack ");
  gCk_PDqgModel->SetName("gCk_PDqgModel");
  gCk_FullModel->SetName("gCk_FullModel");

  unsigned COUNTER = 0;
  for (double k = 5; k < Maxk; k += 5) {
    if (plotall) {
      gCk_PDqgModel->SetPoint(
          COUNTER,
          k,wChannel1* GET_CORRELATION_SIMPSON2D(k, aI0, rI0,
                                          ChargeRad, SourceRad)
              + wChannel1
                  * GET_CORRELATION_SIMPSON2D(k, aI1, rI1, ChargeRad,
                                              SourceRad));
      gCk_FullModel->SetPoint(
          COUNTER,
          k,wChannel1* GET_CORRELATION_SIMPSON2D(k, aI0full, rI0full,
                                          ChargeRad, SourceRad)
              + wChannel1
                  * GET_CORRELATION_SIMPSON2D(k, aI1full, rI1full, ChargeRad,
                                              SourceRad));
    } else{
      gCk->SetPoint(
                COUNTER,k, (0.5*GET_CORRELATION_SIMPSON2D(k, 0.00, 0.0,ChargeRad,SourceRad) + 0.5*GET_CORRELATION_SIMPSON2D(k , 0.0, 0.0,ChargeRad,SourceRad)));

      }
    COUNTER++;
  }
  TString OutputFileName = "";
  if (plotall) {
    OutputFileName =
        OutputFileName

            + "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/ProtonDMeson/CkProtonDMesonStrongCoulomb.root";
  } else {
    OutputFileName =
        OutputFileName
            + "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/ProtonDMeson/CkProtonDMesonCoulomb.root";
  }
  TFile *OutputFile = new TFile(OutputFileName, "recreate");
  printf("File Created\n");
  TCanvas *Plot = new TCanvas("Plot", "Plot", 0, 0, 800, 600);
  TString pdfName = "";
  if (plotall) {
    pdfName =
        pdfName
            + Form(
                "%sCkProtonDMeson.pdf",
                "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/ProtonDMeson/");
  } else {
    pdfName =
        pdfName
            + Form(
                "%sCkProtonDMesonCoulombOnly.pdf",
                "/home/sbhawani/ProtonDeuteron/Outputs/OutputCATSProjects/OutputCATSProjectPD/ProtonDMeson/");
  }
  printf("reached -2!");
  //h1->SetTitle(Form("%s Channel [#Lambda = %i MeV, #it{m}_{#gamma} = %0.1f MeV]", Name.Data(), Cutoff, photonmass));
  if (plotall) {
    gCk_PDqgModel->GetXaxis()->SetTitle("k (MeV/c)");
    gCk_PDqgModel->GetXaxis()->SetTitleSize(0.045);
    gCk_PDqgModel->GetXaxis()->SetTitleOffset(0.5);
    gCk_PDqgModel->GetYaxis()->SetTitleSize(0.045);
    gCk_PDqgModel->GetYaxis()->SetTitleOffset(0.65);
    gCk_PDqgModel->GetYaxis()->SetTitle("#it{C}(k)");

    gCk_PDqgModel->GetXaxis()->SetRangeUser(0, 410);
    gCk_PDqgModel->GetYaxis()->SetRangeUser(0, 10);

    gCk_FullModel->SetLineColor(kRed);
    gCk_FullModel->SetLineWidth(1.5);

    gCk_FullModel->SetLineStyle(10);
    gCk_PDqgModel->SetLineStyle(3);
    gCk_FullModel->SetMarkerStyle(25);
    gCk_PDqgModel->SetMarkerStyle(29);

    TLegend*leg1 = new TLegend(0.5, 0.5, 0.7, 0.65);
    leg1->SetFillStyle(0);
    leg1->SetTextSize(0.04);
    leg1->SetLineColor(0);
    leg1->SetNColumns(1);
    leg1->AddEntry(gCk_PDqgModel, "p-D^{-} q-g Model");
    leg1->AddEntry(gCk_FullModel, "p-D^{-} Full Model");
    gCk_PDqgModel->Draw("ACP");
    gCk_FullModel->Draw("same");

    leg1->Draw("same");
    printf("reached -3!");
    gCk_PDqgModel->Write();
    gCk_FullModel->Write();
    Plot->Print(pdfName);
  } else {
    gCk->GetXaxis()->SetTitle("k (MeV/c)");
    gCk->GetXaxis()->SetTitleSize(0.045);
    gCk->GetXaxis()->SetTitleOffset(0.75);
    gCk->GetYaxis()->SetTitleSize(0.045);
    gCk->GetYaxis()->SetTitleOffset(0.95);
    gCk->GetYaxis()->SetTitle("#it{C}(k)");

    gCk->GetXaxis()->SetRangeUser(0, 400);
    gCk->GetYaxis()->SetRangeUser(0, 10);

    gCk->SetLineColor(kRed);
    gCk->SetLineWidth(2);
    //gSource->MarkerStyle(20);
    //gSource->MarkerSize(1.5);
    TLegend *leg1 = new TLegend(0.2, 0.5, 0.7, 0.65);
    leg1->SetFillStyle(0);
    leg1->SetTextSize(0.04);
    leg1->SetLineColor(0);
    leg1->SetNColumns(1);
    leg1->AddEntry(gCk, " Ck D^{-}-p [a_{0}= 0.07, a_{1} = -0.45]");

    gCk->Draw("ACP");
    leg1->Draw("same");
    printf("reached -3!");
    gCk->Write();
    Plot->Print(pdfName);
  }
  delete Plot;
  delete gCk;
  delete gCk_PDqgModel;
  delete gCk_FullModel;
  delete OutputFile;
}
